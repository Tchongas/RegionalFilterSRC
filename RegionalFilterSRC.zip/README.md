
# SRC++

  

An extension that adds extra functions to Speedrun.com

A Extension of the speedrun.com website that allows users to filter a leaderboarad page by country, and view the game queue on the website, it works by adding 2 buttons to any leaderboard page that the user can click and interact, and it can also be used in the extension pop-up, allowing more settings to be changed

[CHROME STORE DOWNLOAD](https://chrome.google.com/webstore/detail/src-country-filter/bdnajmppanhdhleolpdokdpfofneipjj)
